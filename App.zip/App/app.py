import pymysql.cursors
import groq
from groq import Groq
from pymysql import Error
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# MySQL (Zabbix) database credentials from environment variables
DB_CONFIG = {
    'host': os.getenv('DB_HOST', '208.109.235.220'),
    'port': int(os.getenv('DB_PORT', 9306)),  
    'user': os.getenv('DB_USER', 'viewer'),  
    'password': os.getenv('DB_PASSWORD', 'H28tniRtV441'), 
    'database': os.getenv('DB_NAME', 'vector')
}

# Groq API key from environment variable
GROQ_API_KEY = os.getenv('GROQ_API_KEY', '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')

def connect_to_db():
    """Connect to the Zabbix MySQL database using PyMySQL."""
    try:
        connection = pymysql.connect(
            host=DB_CONFIG['host'],
            port=DB_CONFIG['port'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database'],
            cursorclass=pymysql.cursors.DictCursor # Use DictCursor for dictionary results
        )
        if connection.open: # PyMySQL uses .open to check connection status
            logging.info("Successfully connected to the Zabbix database")
            return connection
    except Error as e:
        logging.error(f"Error connecting to MySQL: {e}")
        return None

def generate_sql_query(natural_query, client):
    """Use Groq API to convert natural language query to SQL query."""
    try:
        prompt = f"""
        You are an expert in generating SQL queries for a Zabbix MySQL database. The database has tables like 'hosts' (columns: hostid, host, name, status), 'items' (columns: itemid, name, lastvalue), and 'events' (columns: eventid, clock, value, name). 
        Convert the following natural language query into a valid SQL query for the Zabbix database. Ensure the query is safe, uses correct table/column names, and includes a LIMIT clause (e.g., LIMIT 10) for safety. Return only the SQL query string, nothing else.
        Natural language query: {natural_query}
        """
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200
        )
        sql_query = response.choices[0].message.content.strip()
        return sql_query
    except Exception as e:
        logging.error(f"Error generating SQL query with Groq API: {e}")
        return None

def fetch_zabbix_data(connection, query):
    """Fetch data from the Zabbix database based on the provided query."""
    try:
        # PyMySQL connection already configured to return dictionaries with DictCursor
        cursor = connection.cursor() 
        cursor.execute(query)
        data = cursor.fetchall()
        return data
    except Error as e:
        logging.error(f"Error fetching data: {e}")
        return []
    finally:
        cursor.close()

def main():
    # Initialize Groq client
    client = Groq(api_key=GROQ_API_KEY)
    
    connection = None # Initialize connection outside the loop

    while True:
        # Prompt for natural language query
        natural_query = input("Enter your query in natural language (e.g., 'What is the status of host zabbix') or type 'exit' to quit: ")
        
        if natural_query.lower() == 'exit':
            logging.info("Exiting application.")
            break

        # Log the user's natural language query
        logging.info(f"User Query: {natural_query}")
        
        # Generate SQL query using Groq API
        sql_query = generate_sql_query(natural_query, client)
        if not sql_query:
            logging.error("Failed to generate SQL query. Please try again.")
            continue # Continue to the next iteration of the loop
        
        logging.info(f"Generated SQL Query: {sql_query}")
        
        # Connect to the database if not already connected
        if not connection or not connection.open:
            connection = connect_to_db()
            if not connection:
                logging.error("Failed to connect to the database. Cannot process query.")
                continue # Continue to the next iteration of the loop

        # Fetch and display data
        data = fetch_zabbix_data(connection, sql_query)
        if data:
            logging.info("\nFetched Data:")
            for row in data:
                logging.info(row)
        else:
            logging.info("No data found or error occurred.")

    # Close the database connection when the loop exits
    if connection and connection.open:
        connection.close()
        logging.info("Database connection closed.")

if __name__ == "__main__":
    main()
