import pymysql.cursors
import groq
from groq import Groq
from pymysql import Error
import os
import logging
from flask import Flask, render_template, request, jsonify

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)

# MySQL (Zabbix) database credentials from environment variables
DB_CONFIG = {
    'host': os.getenv('DB_HOST', '208.109.235.220'),
    'port': int(os.getenv('DB_PORT', 9306)),  
    'user': os.getenv('DB_USER', 'viewer'),  
    'password': os.getenv('DB_PASSWORD', 'H28tniRtV441'), 
    'database': os.getenv('DB_NAME', 'vector')
}

# Groq API key from environment variable
GROQ_API_KEY = os.getenv('GROQ_API_KEY', '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')

# Initialize Groq client globally or within the request context
client = Groq(api_key=GROQ_API_KEY)

def connect_to_db():
    """Connect to the Zabbix MySQL database using PyMySQL."""
    try:
        connection = pymysql.connect(
            host=DB_CONFIG['host'],
            port=DB_CONFIG['port'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database'],
            cursorclass=pymysql.cursors.DictCursor # Use DictCursor for dictionary results
        )
        if connection.open: # PyMySQL uses .open to check connection status
            logging.info("Successfully connected to the Zabbix database")
            return connection
    except Error as e:
        logging.error(f"Error connecting to MySQL: {e}")
        return None

def generate_sql_query(natural_query, client_groq): # Renamed client to client_groq to avoid conflict
    """Use Groq API to convert natural language query to SQL query."""
    try:
        prompt = f"""
        You are an expert in generating SQL queries for a NeeV AI database. The database has tables like 'hosts' (columns: hostid, host, name, status), 'items' (columns: itemid, name, lastvalue), and 'events' (columns: eventid, clock, value, name). 
        Convert the following natural language query into a valid SQL query for the NeeV AI database. Ensure the query is safe, uses correct table/column names, and includes a LIMIT clause (e.g., LIMIT 10) for safety. Return only the SQL query string, nothing else.
        Natural language query: {natural_query}
        """
        response = client_groq.chat.completions.create(
            model="llama3-70b-8192",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200
        )
        sql_query = response.choices[0].message.content.strip()
        return sql_query
    except Exception as e:
        logging.error(f"Error generating SQL query with Groq API: {e}")
        return None

def fetch_zabbix_data(connection, query):
    """Fetch data from the Zabbix database based on the provided query."""
    try:
        cursor = connection.cursor() 
        cursor.execute(query)
        data = cursor.fetchall()
        return data
    except Error as e:
        logging.error(f"Error fetching data: {e}")
        return []
    finally:
        cursor.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def handle_query():
    natural_query = request.json.get('query')
    if not natural_query:
        return jsonify({"error": "No query provided"}), 400

    logging.info(f"User Query: {natural_query}")
    
    sql_query = generate_sql_query(natural_query, client)
    if not sql_query:
        return jsonify({"error": "Failed to generate SQL query."}), 500
    
    logging.info(f"Generated SQL Query: {sql_query}")
    
    connection = connect_to_db()
    if not connection:
        return jsonify({"error": "Failed to connect to the database."}), 500

    data = fetch_zabbix_data(connection, sql_query)
    
    if connection.open:
        connection.close()
        logging.info("Database connection closed.")

    if data:
        logging.info("Fetched Data:")
        for row in data:
            logging.info(row)
        return jsonify({"sql_query": sql_query, "data": data})
    else:
        logging.info("No data found or error occurred.")
        return jsonify({"sql_query": sql_query, "data": [], "message": "No data found or error occurred."})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
